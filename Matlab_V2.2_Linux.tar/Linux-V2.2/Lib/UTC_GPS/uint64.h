#ifndef UINT64_H
#define UINT64_H

typedef unsigned long long uint64;

#endif
