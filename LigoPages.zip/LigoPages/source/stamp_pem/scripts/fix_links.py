import os


# Get all subdirectories and set up "exclusion" list
PATH = os.getcwd()
all_dirs = os.listdir(PATH)
all_dirs = sorted([d for d in all_dirs if os.path.isdir(d)])
exclude = ['bruco_table.html', 'daily_full_coherence_matrix.png', 'detchar_summary.html']

# In each directory, collect all files and set up new suspension filenames
for ad in all_dirs:
    file_path = '{0}/{1}/'.format(PATH, ad)
    files_in_dir = os.listdir(file_path)
    sus_old = [s for s in files_in_dir if "Suspension" in s]
    sus_new = [s.replace(':', '') for s in files_in_dir if "Suspension" in s]
    for i in exclude:
        try:
            files_in_dir.remove(i)
        except:
            pass

    # Make the changes in each file
    for f in files_in_dir:
        for i in range(len(sus_old)):
            cmd = '''sed -i 's/{0}/{1}/g' "{2}{3}"'''.format(sus_old[i], sus_new[i], file_path, f)
            os.system(cmd)

    # Rename the files so that they're consistent with the new changes
    for j in range(len(sus_old)):
        cmd = 'mv "{0}{1}" "{0}{2}"'.format(file_path, sus_old[j], sus_new[j])
        os.system(cmd)
