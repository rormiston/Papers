Week of May 1: Fixing Broken HTML Links
=======================================

* Fixed the "Suspension" problem (going forward)
* Retroactively fixed everything that was already run too!

There is something strange going on with the HTML files where they don't seem
to like the colon used in the filenames (some files get a pass on this and I
cannot explain why that is). I wrote the script below using stream editing
(sed) to change the files without having to open them. Run it from the 
stamppemtest/HTML/day/ directory and it will convert the files from every 
directory. I ran it at LHO and LLO and it worked wonderfully. Hopefully we
won't need the script in the future, but it's there if we do.

I changed a few things in ``make_onine_webpage`` and ``make_webpage_active_segs``
so that this problem does not arise in the future. Merged to ``SelectiveQuery``
branch for further testing first

.. literalinclude:: ../scripts/fix_links.py
   :language: python
   :linenos:

