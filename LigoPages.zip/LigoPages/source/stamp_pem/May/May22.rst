Week of May 22: NGN Improvements
================================
Lots of changes to adapt stamp-pem for the Newtonian Gravitational Noise
pipeline. Small changes include:

* Log scale for plot
* Add channels to list (tilt table, beam rotation)

Other options added:

* Give the option to plot coherence (not coherence SNR) for ease of Wiener filtering later on
* Be able to plot residuals of an entire subsystem between different times

Plane Event Residuals from Feb. 23
++++++++++++++++++++++++++++++++++

.. figure:: ../images/H1-Mic2_1171917018-1171918818.png
   :align: center
   :height: 159 px
   :width: 682 px

   While the plane was passing by.

.. figure:: ../images/H1-Mic2_1171918818-1171920618.png
   :align: center
   :height: 159 px
   :width: 682 px

   After the plane was long gone.


.. figure:: ../images/Microphone2_Residuals.png
   :align: center
   :height: 159 px
   :width: 682 px

   Residual of the two plots above


Output Mode Cleaner Residuals from a Typical Day
++++++++++++++++++++++++++++++++++++++++++++++++

.. figure:: ../images/H1-OMC_1169604018-1169605818.png
   :align: center
   :height: 159 px
   :width: 682 px

   Run over 1169604018 to 1169605818

.. figure:: ../images/H1-OMC_1169607618-1169609418.png
   :align: center
   :height: 159 px
   :width: 682 px

   Run over 1169607618 1169609418

.. figure:: ../images/Output_Mode_Cleaner1_Residuals.png
   :align: center
   :height: 159 px
   :width: 682 px

   Residual of the two plots above

