Week of May 8: Finding a Plane
==============================

Michael found a plane and we can observe it in stamp-pem as well. The middle
plot is during the event (~500s event averaged over 1800s). The plots above
and below come from integrating the 1800s before and 1800s after the event.
The event occured between 1171917018 and 1171918818. The signal is in the
frequency band that we sould expect for a plane (~60-100Hz) and is consistent
with what Michael *et. al* found as well. Here is what Michael saw:

.. figure:: ../images/lsnr.png
   :align: center
   :height: 450 px
   :width: 600 px

   Signal at 1171917126 found my Michael on May 6

Accelerometer 5
+++++++++++++++
.. figure:: ../images/Acc5_before.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Acc5_during.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Acc5_after.png
   :align: center
   :height: 159 px
   :width: 682 px

Accelerometer 6
+++++++++++++++

.. figure:: ../images/Acc6_before.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Acc6_during.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Acc6_after.png
   :align: center
   :height: 159 px


Seismometer 1
+++++++++++++

.. figure:: ../images/Seis1_before.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Seis1_during.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Seis1_after.png
   :align: center
   :height: 159 px
   :width: 682 px

Seismometer 2
+++++++++++++

.. figure:: ../images/Seis2_before.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Seis2_during.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Seis2_after.png
   :align: center
   :height: 159 px
   :width: 682 px

Microphone 2
++++++++++++

.. figure:: ../images/Mic2_before.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Mic2_during.png
   :align: center
   :height: 159 px
   :width: 682 px

.. figure:: ../images/Mic2_after.png
   :align: center
   :height: 159 px
   :width: 682 px

