Useful Papers
=============
* `Gravitational Wave Experiments and Early Universe Cosmology <https://arxiv.org/abs/gr-qc/9909001>`_ - M. Maggiore
* `Gravitational Waves from Cosmic Strings <https://cds.cern.ch/record/327042/files/9706013.pdf>`_ - R.A Battye
* `The Astrophysical Gravitational Wave Stochastic Background <https://arxiv.org/abs/1101.2762>`_ - T. Regimbau
* `GW150914: Implications for the stochastic gravitational wave background from binary black holes <https://arxiv.org/abs/1602.03847>`_ - LSC
* `Gravitational-wave cosmology across 29 decades in frequency <https://arxiv.org/abs/1511.05994>`_ - P. Lansky *et. al*
* `Improved Upper Limits on the Stochastic Gravitational-Wave Background from 2009-2010 LIGO and Virgo Data <https://arxiv.org/abs/1406.4556>`_ - LSC
* `Upper Limits on the Stochastic Gravitational-Wave Background from Advanced LIGO's First Observing Run <https://arxiv.org/abs/1612.02029>`_ - LSC
* `Analysis of First LIGO Science Data for Stochastic Gravitational Waves <https://arxiv.org/abs/gr-qc/0312088>`_ - LSC
* `An Upper Limit on the Stochastic Gravitational-Wave Background of Cosmological Origin <https://arxiv.org/pdf/0910.5772.pdf>`_ - LSC
* `Searches for stochastic gravitational waves and long gravitational wave transients in LIGO S5 data <https://gwic.ligo.org/thesisprize/2013/kandhasamy_thesis.pdf>`_
  - S. Kandhasamy

