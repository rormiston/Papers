from matplotlib import use
use('agg')
import matplotlib.pyplot as plt
import numpy as np
import argparse
import re


def parse_command_line():
    parser = argparse.ArgumentParser()
    parser.add_argument( "--data-file", "-f", help="coherence data file",
                        default=None, type=str, dest='data')
    params = parser.parse_args()
    return params


# Parse the command line and get the file
params = parse_command_line()
data = params.data

# Figure out what the resolution is so we know how to proceed.
# I used regex just in case Tom changes the naming format in the future
resolution = int(re.findall('\d+', data)[0])

if resolution != 1:
    f = open(data)
    lines = f.readlines()
    Nseg = int(float(lines[0].split('\t')[1].strip('\n')))
    freqs = [line.strip('\n').split('\t')[0] for line in lines[2:]]
    Nfreqs = len(freqs)
    Coh = [float(line.strip('\n').split('\t')[1]) for line in lines[2:]]
    bins = np.linspace(0, max(Coh), 75)
    dCoh = bins[1] - bins[0]
    predicted = [Nfreqs * dCoh * Nseg * np.exp(-Nseg * Coh[i]) for i in range(len(Coh))]
    gamma = np.log(Nseg * Nfreqs * dCoh) / Nseg
elif resolution == 1:
    data_dict = np.load('coherence_1mHz.dat')[0]
    Nseg = data_dict['NSeg']
    Coh = data_dict['Coh']
    freqs = data_dict['f']
    Nfreqs = len(freqs)
    bins = np.linspace(0, max(Coh), 75)
    dCoh = bins[1] - bins[0]
    gamma = np.log(dCoh * Nfreqs * Nseg) / Nseg
    predicted = Nfreqs * dCoh * Nseg * np.exp(-Nseg * Coh)
else:
    print('Hmm, not sure what resolution this file is...')

# Make the plots
plt.hist(Coh, bins=bins)
cutoff = plt.axvline(np.abs(gamma), color='red')
plt.axvline(np.abs(gamma), color='red')
prediction, = plt.plot(Coh, predicted, color='green')
plt.plot(Coh, predicted, color='green')
plt.yscale('log')
plt.xlabel('coherence $\Gamma$')
plt.ylabel('log(N)')
plt.legend([prediction, cutoff], ['Predicted', 'Threshold'])
axes = plt.gca()
axes.set_ylim(0.1)
plt.title('Coherence Histogram {}mHz'.format(resolution))
plt.savefig('{}mHz_coherence'.format(resolution))

# Find frequencies to remove and write it to a file
exclude = [(freqs[i], Coh[i]) for i in range(len(Coh)) if Coh[i] > np.abs(gamma)]
print('{} frequencies above coherence threshold'.format(len(exclude)))
fname = 'coherence_lines_{}mHz.txt'.format(resolution)
print('Writing data to {}'.format(fname))
with open(fname, 'w') as f:
    f.write('Frequencies  \tCoherence\n')
    for tup in exclude:
        f.write('{0}\t{1}\n'.format(tup[0], tup[1])) 
