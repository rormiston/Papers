Making Coherence Histograms from StochMon
=========================================
Binning the data from Stochmon (:math:`C(f)` vs. :math:`f`) from the start of O2 until April 17, we
calculate the predicted coherence and start looking for excess SNR by plotting

.. math::
   N = \sum_{i} N_f \Delta \Gamma N_s e^{-\alpha N_s \Gamma_i}

on the histograms and setting an upper limit threshold for the value of the coherence, :math:`\Gamma`
that makes :math:`N=1`. Here, :math:`N_f` is the number of frequencies, :math:`N_s` is the number of segments and 
:math:`\alpha` is a normalization constant (usually :math:`11/18`, but unity here). The resulting plots are:

.. figure:: new_250mHz_coherence.png
   :align: center

   250mHz Resolution

.. figure:: new_100mHz_coherence.png
   :align: center

   100mHz Resolution

.. figure:: new_1mHz_coherence.png
   :align: center

   1mHz Resolution

The full code used to create these plots is below

.. literalinclude:: stochLines.py
   :language: python
   :linenos:

