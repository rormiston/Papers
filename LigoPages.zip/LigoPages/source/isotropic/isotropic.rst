++++++++++++++++
Isotropic Search
++++++++++++++++

A wide variety of astrophysical and cosmological sources are expected to contribute to a stochastic
gravitational-wave background. Following the observations of GW150914 and GW151226, the rate
and mass of coalescing binary black holes appear to be greater than many previous expectations. As
a result, the stochastic background from unresolved compact binary coalescences is expected to be
particularly loud. We perform a search for the isotropic stochastic gravitational-wave background
using data from Advanced LIGO’s first observing run. The data display no evidence of a stochastic
gravitational-wave signal. We constrain the dimensionless energy density of gravitational waves to
be :math:`\Omega_0 < 1.7 × 10−7` with 95% confidence, assuming a flat energy density spectrum in the most
sensitive part of the LIGO band (20 − 86 Hz). This is a factor of ∼33 times more sensitive than
previous measurements. We also constrain arbitrary power-law spectra

.. figure:: Omega0.png
   :align: center
   :height: 400 px
   :width: 450 px

   FIG 1. Estimator for :math:`\Omega_0` in each frequency bin, along with
   :math:`\pm 2\sigma` error bars, in the frequency band that contains
   99% of the sensitivity for :math:`\alpha = 0`. The loss of
   sensitivity at around 65Hz is due to a zero in the overlap reduction
   function. There are several lines associated with known instrumental
   artifacts which do not lead to excess cross-correlation. The data are consistent
   with Gaussian noise


.. figure:: OmegaGW.png
   :align: center
   :height: 400 px
   :width: 500 px

   FIG 2. A range of potential spectra for a BBH
   background, using the flat-log, power-law, and 3-delta mass
   distribution models, with the local rate inferred from the O1
   detections. For the flat-log and power-law distributions,
   we show the 90% Poisson uncertainty band due to the uncertainty
   in the local rate measurement. In addition, we show the measured
   O1 PI curve and the projected PI curve for Advanced LIGO-Virgo
   operating at design sensitivity.



Contents:

.. toctree::
   :maxdepth: 2

   Lines.rst
   UsefulPapers.rst

