.. Ligo Docs documentation master file, created by
   sphinx-quickstart on Fri Apr 21 12:21:01 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Rich's Ligo Docs
================

.. figure:: waveform.jpg
   :align: center

This is a collection of projects, research and related interests

Contents:

.. toctree::
   :maxdepth: 2

   isotropic/isotropic 
   stamp_pem/stamp_pem


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

